package co.edu.uniquindio.poo.proyectofinal;

import co.edu.uniquindio.poo.proyectofinal.model.Cliente;
import co.edu.uniquindio.poo.proyectofinal.model.MonederoAhorros;
import co.edu.uniquindio.poo.proyectofinal.model.MonederoGastos;
import co.edu.uniquindio.poo.proyectofinal.model.MonederoVirtual;
import co.edu.uniquindio.poo.proyectofinal.viewController.ClienteViewController;
import co.edu.uniquindio.poo.proyectofinal.viewController.PrimaryViewController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Clase principal de JavaFX. Guarda la única instancia de MonederoVirtual
 * (static, como la Empresa de la práctica) y abre las vistas.
 */
public class App extends Application {

    private Stage primaryStage;
    public static MonederoVirtual monederoVirtual = new MonederoVirtual("Monedero UQ");

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Monedero virtual");
        inicializarData();          // una sola vez, al arrancar
        openViewPrincipal();
    }

    public void openViewPrincipal() {
        try {
            FXMLLoader loader = new FXMLLoader(App.class.getResource("primary.fxml"));
            Parent rootLayout = loader.load();
            PrimaryViewController controller = loader.getController();
            controller.setApp(this);
            mostrar(rootLayout);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void openCrudCliente() {
        try {
            FXMLLoader loader = new FXMLLoader(App.class.getResource("crudCliente.fxml"));
            Parent rootLayout = loader.load();
            ClienteViewController controller = loader.getController();
            controller.setApp(this);
            mostrar(rootLayout);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void mostrar(Parent rootLayout) {
        primaryStage.setScene(new Scene(rootLayout));
        primaryStage.show();
    }

    /** Datos de ejemplo para probar la interfaz (se pierden al cerrar la aplicación). */
    private void inicializarData() {
        try {
            Cliente juan = new Cliente("1001", "Juan Pérez", "juan@mail.com", "3001112233");
            Cliente maria = new Cliente("1002", "María Gómez", "maria@mail.com", "3109998877");
            monederoVirtual.registrarCliente(juan);
            monederoVirtual.registrarCliente(maria);
            monederoVirtual.agregarMonedero("1001", new MonederoGastos("Gastos diarios"));
            monederoVirtual.agregarMonedero("1001", new MonederoAhorros("Ahorros"));
            monederoVirtual.agregarMonedero("1002", new MonederoGastos("Principal"));
        } catch (Exception e) {
            System.out.println("No se pudieron cargar los datos de ejemplo: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
