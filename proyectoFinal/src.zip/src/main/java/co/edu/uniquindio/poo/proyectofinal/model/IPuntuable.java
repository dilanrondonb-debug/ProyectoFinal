package co.edu.uniquindio.poo.proyectofinal.model;

public interface IPuntuable {
    public int calcularPuntos();
}
