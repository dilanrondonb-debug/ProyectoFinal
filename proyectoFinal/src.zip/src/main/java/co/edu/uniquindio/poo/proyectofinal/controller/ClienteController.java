package co.edu.uniquindio.poo.proyectofinal.controller;

import co.edu.uniquindio.poo.proyectofinal.model.Cliente;
import co.edu.uniquindio.poo.proyectofinal.model.MonederoException;
import co.edu.uniquindio.poo.proyectofinal.model.MonederoGastos;
import co.edu.uniquindio.poo.proyectofinal.model.MonederoVirtual;

import java.util.List;

/**
 * Intermediario entre la vista y el model: la vista nunca habla directo con
 * MonederoVirtual. Aquí no hay reglas de negocio; solo se delega.
 */
public class ClienteController {

    private final MonederoVirtual monederoVirtual;

    public ClienteController(MonederoVirtual monederoVirtual) {
        this.monederoVirtual = monederoVirtual;
    }

    /** Crea el cliente y le asigna un monedero principal (todo cliente necesita al menos uno). */
    public Cliente crearCliente(String cedula, String nombre, String correo, String telefono)
            throws MonederoException {
        Cliente cliente = new Cliente(cedula, nombre, correo, telefono);   // valida los datos
        monederoVirtual.registrarCliente(cliente);                          // valida que no esté repetido
        monederoVirtual.agregarMonedero(cedula, new MonederoGastos("Principal"));
        return cliente;
    }

    public List<Cliente> obtenerClientes() {
        return monederoVirtual.getClientes();
    }

    public void actualizarCliente(String cedula, String nombre, String correo, String telefono)
            throws MonederoException {
        // Se validan TODOS los datos antes de tocar al cliente real; si no, un correo
        // inválido dejaría el nombre ya cambiado y el cliente a medio actualizar.
        new Cliente(cedula, nombre, correo, telefono);
        monederoVirtual.actualizarCliente(cedula, nombre, correo, telefono);
    }

    public void eliminarCliente(String cedula) throws MonederoException {
        monederoVirtual.eliminarCliente(cedula);
    }
}
