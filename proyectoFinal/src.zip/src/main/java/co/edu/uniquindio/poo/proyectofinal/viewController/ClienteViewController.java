package co.edu.uniquindio.poo.proyectofinal.viewController;

import co.edu.uniquindio.poo.proyectofinal.App;
import co.edu.uniquindio.poo.proyectofinal.controller.ClienteController;
import co.edu.uniquindio.poo.proyectofinal.model.Cliente;
import co.edu.uniquindio.poo.proyectofinal.model.MonederoException;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.util.Optional;

/** Controlador de crudCliente.fxml: solo maneja controles gráficos y delega todo en ClienteController. */
public class ClienteViewController {

    private ClienteController clienteController;
    private final ObservableList<Cliente> listClientes = FXCollections.observableArrayList();
    private Cliente selectedCliente;
    private App app;

    @FXML private TextField txtCedula;
    @FXML private TextField txtNombre;
    @FXML private TextField txtCorreo;
    @FXML private TextField txtTelefono;

    @FXML private TableView<Cliente> tblListCliente;
    @FXML private TableColumn<Cliente, String> tbcCedula;
    @FXML private TableColumn<Cliente, String> tbcNombre;
    @FXML private TableColumn<Cliente, String> tbcCorreo;
    @FXML private TableColumn<Cliente, String> tbcTelefono;
    @FXML private TableColumn<Cliente, String> tbcRango;
    @FXML private TableColumn<Cliente, Number> tbcPuntos;

    // ---------- Eventos de los botones ----------

    @FXML
    void onAgregarCliente() {
        agregarCliente();
    }

    @FXML
    void onActualizarCliente() {
        actualizarCliente();
    }

    @FXML
    void onEliminar() {
        eliminarCliente();
    }

    @FXML
    void onLimpiar() {
        limpiarSeleccion();
    }

    @FXML
    void onVolver() {
        app.openViewPrincipal();
    }

    // ---------- Inicialización ----------

    @FXML
    void initialize() {
        clienteController = new ClienteController(App.monederoVirtual);
        initDataBinding();
        listClientes.setAll(clienteController.obtenerClientes());
        tblListCliente.setItems(listClientes);
        listenerSelection();
    }

    private void initDataBinding() {
        tbcCedula.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getCedula()));
        tbcNombre.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getNombre()));
        tbcCorreo.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getCorreo()));
        tbcTelefono.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getTelefono()));
        tbcRango.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getRango().name()));
        tbcPuntos.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getPuntos()));
    }

    private void listenerSelection() {
        tblListCliente.getSelectionModel().selectedItemProperty().addListener((obs, anterior, nuevo) -> {
            selectedCliente = nuevo;
            mostrarInformacionCliente(nuevo);
        });
    }

    private void mostrarInformacionCliente(Cliente cliente) {
        if (cliente != null) {
            txtCedula.setText(cliente.getCedula());
            txtNombre.setText(cliente.getNombre());
            txtCorreo.setText(cliente.getCorreo());
            txtTelefono.setText(cliente.getTelefono());
            txtCedula.setDisable(true);   // la cédula identifica al cliente: no se edita
        }
    }

    // ---------- Acciones ----------

    private void agregarCliente() {
        try {
            Cliente cliente = clienteController.crearCliente(
                    txtCedula.getText(), txtNombre.getText(), txtCorreo.getText(), txtTelefono.getText());
            listClientes.add(cliente);
            limpiarSeleccion();
            mostrarMensaje("Cliente registrado",
                    cliente.getNombre() + " fue registrado con su monedero principal.",
                    Alert.AlertType.INFORMATION);
        } catch (MonederoException e) {
            mostrarMensaje("No se pudo registrar", e.getMessage(), Alert.AlertType.WARNING);
        }
    }

    private void actualizarCliente() {
        if (selectedCliente == null) {
            mostrarMensaje("Seleccione un cliente", "Elija un cliente de la tabla para actualizarlo.",
                    Alert.AlertType.INFORMATION);
            return;
        }
        try {
            clienteController.actualizarCliente(selectedCliente.getCedula(),
                    txtNombre.getText(), txtCorreo.getText(), txtTelefono.getText());
            tblListCliente.refresh();
            limpiarSeleccion();
        } catch (MonederoException e) {
            mostrarMensaje("No se pudo actualizar", e.getMessage(), Alert.AlertType.WARNING);
        }
    }

    private void eliminarCliente() {
        if (selectedCliente == null) {
            mostrarMensaje("Seleccione un cliente", "Elija un cliente de la tabla para eliminarlo.",
                    Alert.AlertType.INFORMATION);
            return;
        }
        Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Eliminar a " + selectedCliente.getNombre() + "?");
        confirmacion.setHeaderText(null);
        Optional<ButtonType> respuesta = confirmacion.showAndWait();
        if (respuesta.isPresent() && respuesta.get() == ButtonType.OK) {
            try {
                clienteController.eliminarCliente(selectedCliente.getCedula());
                listClientes.remove(selectedCliente);
                limpiarSeleccion();
            } catch (MonederoException e) {
                mostrarMensaje("No se pudo eliminar", e.getMessage(), Alert.AlertType.WARNING);
            }
        }
    }

    private void limpiarSeleccion() {
        tblListCliente.getSelectionModel().clearSelection();
        selectedCliente = null;
        txtCedula.clear();
        txtNombre.clear();
        txtCorreo.clear();
        txtTelefono.clear();
        txtCedula.setDisable(false);
    }

    private void mostrarMensaje(String titulo, String mensaje, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    public void setApp(App app) {
        this.app = app;
    }
}
