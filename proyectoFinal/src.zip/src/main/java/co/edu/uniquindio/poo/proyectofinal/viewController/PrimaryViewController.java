package co.edu.uniquindio.poo.proyectofinal.viewController;

import co.edu.uniquindio.poo.proyectofinal.App;
import javafx.fxml.FXML;

/** Controlador de la ventana de bienvenida (primary.fxml). */
public class PrimaryViewController {

    private App app;

    @FXML
    void onOpenCrudCliente() {
        app.openCrudCliente();
    }

    public void setApp(App app) {
        this.app = app;
    }
}
